export class Phone {
  number?: string;
  type?: string;
}
